import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hero',
  standalone: true,
  imports: [ CommonModule],
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css']
})
export class HeroComponent {
  categories = [
    { name: 'Food Delivery', description: 'From Restaurants', discount: 'UPTO 60% OFF', image: 'path/to/food-delivery.jpg' },
    { name: 'Instamart', description: 'Instant Grocery', discount: 'UPTO 60% OFF', image: 'path/to/instamart.jpg' },
    { name: 'Dineout', description: 'Eat Out & Save More', discount: 'UPTO 50% OFF', image: 'path/to/dineout.jpg' },
    { name: 'Genie', description: 'Pick-Up & Drop', discount: '', image: 'path/to/genie.jpg' }
  ];

}
