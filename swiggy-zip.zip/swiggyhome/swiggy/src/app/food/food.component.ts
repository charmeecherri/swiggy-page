import { Component } from '@angular/core';
import { NgFor } from '@angular/common';
import {  ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-food',
  standalone: true,
  imports: [NgFor],
  templateUrl: './food.component.html',
  styleUrl: './food.component.css'
})
export class FoodComponent {
 
    @ViewChild('carousel', { static: false }) carousel!: ElementRef;
  
    foodItems = [
    { name: 'Biryani', image: 'assets/images/biryani.avif' },
    { name: 'Pizza', image: 'assets/images/pizza.jpeg' },
    { name: 'Burgers', image: 'assets/images/burger.jpg' },
    { name: 'Chinese', image: 'assets/images/chinese.jpeg' },
    { name: 'pav Bhaji', image: 'assets/images/pavbhaji.png' },
    { name: 'Salads', image: 'assets/images/salad.png' },
    { name: 'Shake', image: 'assets/images/shake.png' },
    { name: 'Pure Veg', image: 'assets/images/pureveg.png' },
    { name: 'Dosa', image: 'assets/images/dosa.png' },
    ];
  
    scrollLeft(): void {
      this.carousel.nativeElement.scrollBy({
        left: -200,
        behavior: 'smooth'
      });
    }
  
    scrollRight(): void {
      this.carousel.nativeElement.scrollBy({
        left: 200,
        behavior: 'smooth'
      });
    }
  }

