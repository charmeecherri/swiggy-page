// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-menu',
//   standalone: true,
//   imports: [],
//   templateUrl: './menu.component.html',
//   styleUrl: './menu.component.css'
// })
// export class MenuComponent {

// }
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantService } from '../restaurant.service';
import { NgIf, NgFor } from '@angular/common';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [NgIf, NgFor],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css' // Corrected 'styleUrl' to 'styleUrls'
})
export class MenuComponent implements OnInit {
  restaurant: any;

  constructor(
    private route: ActivatedRoute,
    private restaurantService: RestaurantService
  ) {}

  ngOnInit(): void {
    this.loadRestaurantData();
  }

  private loadRestaurantData(): void {
    const restaurantId = Number(this.route.snapshot.paramMap.get('id'));
    this.restaurantService.getRestaurantById(restaurantId).subscribe(
      (restaurant) => {
        this.restaurant = restaurant;
        console.log('Restaurant data:', this.restaurant); // For debugging
      },
      (error) => console.error('Error fetching restaurant data:', error)
    );
  }

  addToCart(item: any): void {
    const { id, name } = this.restaurant;
    this.restaurantService.addToCart(id, name, item, item.quantity || 0);
    alert(`${item.name} added to cart!`);
  }

  increaseQuantity(item: any): void {
    item.quantity = (item.quantity || 0) + 1;
  }

  decreaseQuantity(item: any): void {
    if (item.quantity && item.quantity > 0) {
      item.quantity--;
    }
  }
}
